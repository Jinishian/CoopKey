# CoopKey Android project

No computer setup needed: see GITHUB-BUILD-GUIDE.md to build the APK on GitHub. The steps below are for building locally on Windows.

A minimal Tauri v2 wrapper around your single-file CoopKey app (index.html). You don't need the original repo for this.

## Steps (Windows PowerShell)
1. Install: Node.js LTS, Rust (rustup.rs), Android Studio (then in SDK Manager add NDK Side by side,
   Command-line Tools, Platform-Tools, Build-Tools). Turn on Windows Developer Mode.
2. `www\index.html` is already your CoopKey v0.13 (payments, lineage, photos).
3. `.\setup-android.ps1`
4. Phone: Settings > About phone > tap Build number 7 times > Developer options > USB debugging on. Plug in.
5. `.\build-android.ps1 -Install`   (debug APK, arm64, installs over USB)
   Without a cable: run `.\build-android.ps1`, copy the APK from
   `src-tauri\gen\android\app\build\outputs\apk\` to the phone, and allow "Install unknown apps".
6. Signed release later: `.\build-android.ps1 -Release` (creates coopkey.keystore, back it up).

## Notes
- App ID is `com.jinishian.coopkey` (change in `src-tauri/tauri.conf.json` before first install if you want another).
- Data in localStorage/IndexedDB starts empty on the phone.
- If your Cloudflare Worker restricts CORS, allow the app's origin (likely `http://tauri.localhost`
  or `https://tauri.localhost`) or sync calls from the Android app may be blocked.
- The PWA service worker won't register inside the app; that's harmless.
- `app-icon.png` is a placeholder; replace it with a 1024x1024 logo and run `npm run tauri icon app-icon.png`.

- Bird photos are stored on the device only (like journal photos); they don't sync between devices.
- Test on the phone: Take photo should open the camera. If it doesn't, the Gallery button still works.
- Printing: in the Android app, Print opens Android's print dialog (choose a printer or Save as PDF). The cloud build adds this automatically; if that step fails, the build falls back to an APK without printing and shows a warning in the run log.

- Web and cloud: see `WEB-GUIDE.md` (host it in any browser) and `worker/DEPLOY-GUIDE.md` (accounts and cross-device sync).
