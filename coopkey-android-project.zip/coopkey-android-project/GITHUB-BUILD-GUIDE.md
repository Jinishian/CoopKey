# Build the CoopKey APK on GitHub (no installs needed)

## One-time setup
1. Go to github.com, sign in, and tap + > New repository. Name it `CoopKey-android`, choose **Private**, create it.
2. Unzip this project (on a Chromebook: Files app > right-click the zip > Extract all).
3. Your CoopKey v0.13 `index.html` (payments, lineage, photos) is already in the `www` folder.
4. In the new repo choose **Add file > Upload files**. Drag in everything from inside the project folder
   (www, src-tauri, package.json, app-icon.png, .gitignore, .github, etc.). Commit.
5. Check the repo shows `.github/workflows/build-apk.yml`. If the hidden `.github` folder didn't upload:
   **Add file > Create new file**, type `.github/workflows/build-apk.yml` as the name (typing the slashes makes
   the folders), paste the contents of `build-apk.yml`, and commit.
6. Also check `www/index.html` is in the repo (it should be about 200 KB).

## Build
1. Repo > **Actions** tab > "Build CoopKey APK" > **Run workflow** > Run workflow.
   (If prompted to enable workflows, enable them.)
2. Wait about 10 to 20 minutes (the first run is slowest). Green check = done.

## Install on your phone
1. On your phone, open the repo in a browser, signed in to GitHub.
2. Tap **Releases** > the newest build > tap `coopkey-debug.apk` to download.
3. Open the downloaded file. If asked, allow "Install unknown apps" for your browser, then install.

## Printing from the phone
Tap Print on an invoice and Android's print dialog opens. Pick "Save as PDF" to get a file you can send, or choose a printer.
If the run shows a yellow warning about the print bridge, the app still built but printing won't work in that build; paste the warning log here.

## If it fails
Open the failed run, tap the red step, and copy the last 30 or so lines of the log to Claude.

## Later changes
Replace `www/index.html` in the repo (open it > pencil/upload) and run the workflow again.
Turn on the "universal" option only if the APK won't install on an older phone.
