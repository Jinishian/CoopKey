# Align and sign a release APK. Creates a keystore on first run.
# BACK UP coopkey.keystore and its password. Losing it means you can't update installed copies.
param(
  [Parameter(Mandatory = $true)][string]$Apk,
  [string]$Keystore = "coopkey.keystore",
  [string]$Alias = "coopkey",
  [string]$Out = "coopkey-signed.apk"
)
$ErrorActionPreference = "Stop"

$bt = Get-ChildItem "$env:ANDROID_HOME\build-tools" -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $bt) { throw "No build-tools found. Install 'Android SDK Build-Tools' in SDK Manager." }
$zipalign  = Join-Path $bt.FullName "zipalign.exe"
$apksigner = Join-Path $bt.FullName "apksigner.bat"
$keytool   = Join-Path $env:JAVA_HOME "bin\keytool.exe"

if (!(Test-Path $Keystore)) {
  Write-Host "Creating keystore $Keystore (you'll be prompted for a password and details)..."
  & $keytool -genkey -v -keystore $Keystore -alias $Alias -keyalg RSA -keysize 2048 -validity 10000
}

$aligned = "coopkey-aligned.apk"
if (Test-Path $aligned) { Remove-Item $aligned }
& $zipalign -v -p 4 $Apk $aligned
if ($LASTEXITCODE -ne 0) { throw "zipalign failed." }

& $apksigner sign --ks $Keystore --ks-key-alias $Alias --out $Out $aligned
if ($LASTEXITCODE -ne 0) { throw "apksigner failed." }
& $apksigner verify $Out
Remove-Item $aligned -ErrorAction SilentlyContinue
Write-Host "Signed APK: $Out"
