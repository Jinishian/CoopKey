# CoopKey Android setup. Run once from this folder in PowerShell, after putting index.html in www\.
$ErrorActionPreference = "Stop"

if (!(Test-Path "www\index.html")) { throw "Put your CoopKey index.html in the www folder first." }

foreach ($tool in @("node", "npm", "rustup", "cargo")) {
  if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "$tool not found. Install Node.js LTS and Rust (https://rustup.rs) first." }
}

$sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { "$env:LOCALAPPDATA\Android\Sdk" }
$jdk = if ($env:JAVA_HOME) { $env:JAVA_HOME } else { "C:\Program Files\Android\Android Studio\jbr" }

if (!(Test-Path $sdk)) { throw "Android SDK not found at $sdk. Install Android Studio and the SDK first." }
if (!(Test-Path "$jdk\bin\java.exe")) { throw "JDK not found at $jdk. Set JAVA_HOME or install Android Studio." }

$ndk = Get-ChildItem "$sdk\ndk" -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if (-not $ndk) { throw "NDK not found. In Android Studio: SDK Manager > SDK Tools > NDK (Side by side)." }

$dev = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock" -ErrorAction SilentlyContinue
if (-not $dev -or $dev.AllowDevelopmentWithoutDevLicense -ne 1) {
  Write-Warning "Windows Developer Mode looks off. Turn it on in Settings > For developers, or the build may fail on symlinks."
}

foreach ($pair in @{ JAVA_HOME = $jdk; ANDROID_HOME = $sdk; NDK_HOME = $ndk.FullName }.GetEnumerator()) {
  [Environment]::SetEnvironmentVariable($pair.Key, $pair.Value, "User")
  Set-Item -Path "Env:$($pair.Key)" -Value $pair.Value
  Write-Host "$($pair.Key) = $($pair.Value)"
}

Write-Host "`nAdding Rust Android targets..."
rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android

Write-Host "`nInstalling npm packages..."
npm install

if (!(Test-Path "src-tauri\icons\icon.ico")) {
  Write-Host "`nGenerating app icons from app-icon.png (replace that file with your own 1024x1024 logo anytime)..."
  npm run tauri icon app-icon.png
}

if (!(Test-Path "src-tauri\gen\android")) {
  Write-Host "`nInitializing Tauri Android project..."
  npm run tauri android init
} else {
  Write-Host "`nsrc-tauri\gen\android already exists, skipping init."
}

Write-Host "`nDone. Next: .\build-android.ps1 -Install"
