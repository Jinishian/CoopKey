// CoopKey settings you can change without touching index.html.
// Paste your Worker address between the quotes to turn on accounts and cross-device sync, for example:
//   window.COOPKEY_CLOUD = 'https://coopkey-api.yourname.workers.dev';
window.COOPKEY_CLOUD = '';
