"""Adds a native print bridge to the generated Android MainActivity.

Android's WebView ignores window.print(). This exposes window.CoopKeyNative.print(jobName),
which hands the current page to Android's print framework (print to a printer or Save as PDF).
The app's existing @media print rules decide what is printed.

Usage:  python3 scripts/patch_android_print.py            apply the patch
        python3 scripts/patch_android_print.py --revert   restore the original MainActivity.kt
"""
import glob, os, re, shutil, sys

files = glob.glob('src-tauri/gen/android/app/src/main/java/**/MainActivity.kt', recursive=True)
if not files:
    sys.exit('MainActivity.kt not found. Run "tauri android init" first.')
path = files[0]
orig = path + '.orig'

if '--revert' in sys.argv:
    if os.path.exists(orig):
        shutil.copyfile(orig, path)
        print('Reverted', path)
    else:
        print('Nothing to revert')
    sys.exit(0)

src = open(path, encoding='utf-8').read()
if 'CoopKeyNative' in src:
    print('Already patched')
    sys.exit(0)
shutil.copyfile(path, orig)

imports = [
    'import android.print.PrintAttributes',
    'import android.print.PrintManager',
    'import android.webkit.JavascriptInterface',
    'import android.webkit.WebView',
]
missing = [i for i in imports if i not in src]
pk = re.search(r'^package .*$', src, flags=re.M)
if not pk:
    sys.exit('package line not found')
src = src[:pk.end()] + '\n\n' + '\n'.join(missing) + src[pk.end():]

members = '''

  private var coopkeyWebView: WebView? = null

  override fun onWebViewCreate(webView: WebView) {
    super.onWebViewCreate(webView)
    coopkeyWebView = webView
    webView.addJavascriptInterface(CoopKeyPrintBridge(), "CoopKeyNative")
  }

  inner class CoopKeyPrintBridge {
    @JavascriptInterface
    fun print(jobName: String) {
      runOnUiThread {
        val wv = coopkeyWebView ?: return@runOnUiThread
        val pm = getSystemService(PRINT_SERVICE) as PrintManager
        pm.print(jobName, wv.createPrintDocumentAdapter(jobName), PrintAttributes.Builder().build())
      }
    }
  }
'''

m = re.search(r'class\s+MainActivity\s*:\s*TauriActivity\(\)\s*\{', src)
if m:
    src = src[:m.end()] + members + src[m.end():]
else:
    m = re.search(r'class\s+MainActivity\s*:\s*TauriActivity\(\)', src)
    if not m:
        sys.exit('MainActivity class declaration not found')
    src = src[:m.end()] + ' {' + members + '}\n' + src[m.end():]

open(path, 'w', encoding='utf-8').write(src)
print('Patched', path)
