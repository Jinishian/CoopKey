# Build the CoopKey APK. Run from the CoopKey repo root.
#   .\build-android.ps1                 debug APK, arm64 only (fast, installs as-is)
#   .\build-android.ps1 -Release        release APK, then signs it
#   .\build-android.ps1 -Install        also installs on a USB-connected phone
#   .\build-android.ps1 -Universal      all CPU architectures (bigger, slower)
param(
  [switch]$Release,
  [switch]$Install,
  [switch]$Universal
)
$ErrorActionPreference = "Stop"

$buildArgs = @("--apk")
if (-not $Release)   { $buildArgs += "--debug" }
if (-not $Universal) { $buildArgs += @("--target", "aarch64") }

Write-Host "Running: npm run tauri android build -- $($buildArgs -join ' ')"
npm run tauri android build -- @buildArgs
if ($LASTEXITCODE -ne 0) { throw "Tauri Android build failed." }

$apkRoot = "src-tauri\gen\android\app\build\outputs\apk"
$kind = if ($Release) { "release" } else { "debug" }
$apk = Get-ChildItem $apkRoot -Recurse -Filter "*.apk" |
  Where-Object { $_.FullName -match "\\$kind\\" } |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $apk) { throw "No $kind APK found under $apkRoot" }
$final = $apk.FullName

if ($Release -and $apk.Name -match "unsigned") {
  Write-Host "`nRelease APK is unsigned, signing..."
  & "$PSScriptRoot\sign-apk.ps1" -Apk $apk.FullName
  $final = Join-Path (Get-Location) "coopkey-signed.apk"
}

Write-Host "`nAPK ready: $final"

if ($Install) {
  $adb = Join-Path $env:ANDROID_HOME "platform-tools\adb.exe"
  if (!(Test-Path $adb)) { throw "adb not found. Install 'Android SDK Platform-Tools' in SDK Manager." }
  & $adb devices
  & $adb install -r $final
}
